window.addEventListener("load", () => {
  document.getElementById("loading").style.display = "none";
});
