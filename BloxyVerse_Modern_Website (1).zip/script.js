
window.addEventListener('load', () => {
  setTimeout(() => {
    document.querySelector('.loading-screen').style.display = 'none';
  }, 1500);
});
